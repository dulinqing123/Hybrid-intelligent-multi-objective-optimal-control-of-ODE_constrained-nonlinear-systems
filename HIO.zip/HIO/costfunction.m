function obj=costfunction(ui)
global T N x0 lb ub R Y xbest xxi y0 costfunctiony0
Y = constraints(ui);
    if Y <= 0
        y0=[0.1 14 0 5];
        options = odeset('RelTol', 1e-1, 'AbsTol', 1e-4, 'Refine', R);
        for i = 1:N
            [t,x]=ode45(@(t,x)defineodeu(t,x,ui(:,i)),[(i-1)*T/(N),i*T/(N)],y0,options);
            y0 = x(end, :);
        end
        obj = -x(end,3)/(2.8*x(end,4)-x(end,2));%将y1赋值给obj，作为优化问题的目标函数值。
    else
%         y0=[0.1 14 0 5];
%         options = odeset('RelTol', 1e-1, 'AbsTol', 1e-4, 'Refine', R);
%         for i = 1:N
%             [t,x]=ode45(@(t,x)defineodeu(t,x,ui(:,i)),[(i-1)*T/(N),i*T/(N)],y0,options);
%             y0 = x(end, :);
%         end
        obj = 500;
    end
end
