
function [Y] = constraints(ui)
    global T N x0 E2 
    y0 = x0;
%     x = zeros(4, N+1); % 初始化x为一个4行(状态变量)N+1列(时间步)的二维数组
    for i = 1:N
        [t,x] = ode45(@(t,x)defineodeu(t,x,ui(i)), [(i-1)*T/N, i*T/N], y0);
        y0 = x(end, :); % 更新初始条件为当前段的结束状态
    end
    % 约束条件现在基于状态变量x的最后一个时间步
    Y = -x(end,3)/2400 + E2; % 这是一个不等式约束  
 
end



