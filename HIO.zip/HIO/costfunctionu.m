function obj=costfunctionu(u)
global T N x0 NFE
y0=[0.1 14 0 5];
x = zeros(4, N+1);
for i = 1:N
[~,x]=ode45(@(t,x)defineodeu(t,x,u(i)),[(i-1)*T/(N),i*T/(N)],y0);
y0 = x(end, :);
end
obj = -x(end,3)/(2.8*x(end,4)-x(end,2));%将y1赋值给obj，作为优化问题的目标函数值。
NFE=NFE+1;
end
