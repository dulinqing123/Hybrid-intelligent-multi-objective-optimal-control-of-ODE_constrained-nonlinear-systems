close all  % 关闭所有打开的图形窗口，清除命令窗口和所有变量
clc
clear


% current_seed = 2025 + iter;
% rng(current_seed, 'v4');  

H = cputime;
format long
global T N x0 u0  lb ub E2  E NFE FMIN R BEST Y y0 xxi xEi MM gbestx constraintsy0 costfunctiony0
NFE=0;
pm=0.02;
pc=0.5;
T=40;
N=10;
R=400;
u0 = 1;
lb = 0;
ub = 2;
E=[];
ux=[];
FMIN=[];
E2=0.94078;
multi_FBR=[];
MM=[];
BEST=[];
xbest=[];
Iterpso=0;
 while E2>0.40729
    Ao=[];
    Aox=[];
    Aofit=[];
    xxi=[];
    xEi=[];
    x0=[0.1 14 0 5];
    M=20; 
    D=10;
    c1=0.4; 
    c2=0.4; 
    w=0.75; 
    K=20;
    vmax=1;
    vmin=-1;
    for i=1:D
        ximax=2;
        ximin=0;
    end
    record = zeros(1, K);
    %% 产生初始粒子和速度
    for i=1:M
        xi(i,:)=[1;1;1;1;1;1;1;1;1;1];
        v(i,:)= rand(1,D);
        obj(i)=costfunction(xi(i,:)); %计算适应度
    end

    %% 个体极值和群体极值
    pbest=xi;      % 每个个体的历史最佳位置
    fitpbest = obj;  % 每个个体的历史最佳适应度
    [fitbest,nmin]=min(obj);               % 种群的历史最佳位置
    fitgbest = fitbest;                      % 种群历史最佳适应度
    gbest=xi(nmin,:);
    %% 迭代寻优
    t=0;
    lastfitgbest=0;
    while (t<20 && abs(fitgbest-lastfitgbest)>10^-2)
        lastfitgbest=fitgbest;
        t=t+1;
        a=obj;
        c=xi;
        Ae=[];
        Ap=[];
        xxi=[];
        xEi=[];
        for j=1:M
            %速度更新
            v(j,:)=w*v(j,:) + c1*rand*(pbest(j,:)-xi(j,:)) + c2*rand*(gbest-xi(j,:));% 速度更新
            %速度边界处理
            v(j,find(v(j,:)>vmax))=vmax;
            v(j,find(v(j,:)<vmin))=vmin;
            %位置更新
            xi(j,:)=xi(j,:)+v(j,:);
            xi(j,find(xi(j,:)>ximax))=ximax;
            xi(j,find(xi(j,:)<ximin))=ximin;

            obj(j)=costfunction(xi(j,:));

            b(j)=obj(j);
            d(j,:)=xi(j,:);
            distance = pdist2(c(j,:),d(j,:),'euclidean');
            Ir(j)=(a(j)-b(j))/2.71828^distance;
            XI1(j,:)=c(j,:);
            XI2(j,:)=d(j,:);
            Ae=[Ae b(j)];
            Ap=[Ap Ir(j)];


            % 个体最有更新
            if obj(j) < fitpbest(j)
                pbest(j,:) = xi(j,:);   % 更新个体历史最佳位置
                fitpbest(j) = obj(j);     % 更新个体历史最佳适应度
            end
            % 群体最有更新
            if obj(j) < fitgbest
                gbest= xi(j,:);   % 更新群体历史最佳适应度
                fitgbest = obj(j);      % 更新群体历史最佳位置
            end
        end
        [Aesorted,I] = sort(Ae);
        XI1sorted = XI1(I,:);
        [Apsorted,I] = sort(Ap);
        XI2sorted = XI2(I,:);
        Pk1=[];
        Pk2=[];
        for j=1:M
            pk1=(M-j+1)/(M*(M+1)/2);
            pk2=j/(M*(M+1)/2);
            Pk1=[Pk1 pk1];
            Pk2=[Pk2 pk2];
        end
        for i=1:M
            % 计算累积概率
            cumulative_Pk1 = cumsum(Pk1);
            cumulative_Pk2 = cumsum(Pk2);
            % 生成一个随机数
            r1 = rand;
            r2 = rand;
            % 找到对应的索引
            selected_index1 = find(r1 <= cumulative_Pk1, 1);
            selected_index2 = find(r2 <= cumulative_Pk2, 1);
            % 获取抽到的元素
            selected_element1 = Aesorted(selected_index1);
            selected_element2 = Apsorted(selected_index2);
            father=XI1sorted (selected_index1,:);
            mother=XI2sorted (selected_index2,:);
            for j = 1:D
                rc = rand;
                if rc > pc
                    Ei(i,j) = father(:,j);
                else
                    Ei(i,j) = mother(:,j);
                end
            end
            for j = 1:D
                rm = rand;
                if rm < pm
                    Ei(i,j) = rand * 2;
                end
            end
            objEi(i)=costfunction(Ei(i,:));
        end
        for i=1:M
            if objEi(i) < fitgbest
                for j=1:D
                    v(i,j)=w*v(i,j)+c1*rand*(Ei(i,j)-xi(i,j));
                    v(i,find(v(i,j)>vmax))=vmax;
                    v(i,find(v(i,j)<vmin))=vmin;
                end
                gbest= Ei(i,:);
                fitgbest = objEi(i);
            elseif objEi(i) < fitpbest(i)
                for j=1:D
                    v(i,j)=w*v(i,j)+c1*rand*(Ei(i,j)-xi(i,j))+c2*rand*(gbest(j)-xi(i,j));
                    v(i,find(v(i,j)>vmax))=vmax;
                    v(i,find(v(i,j)<vmin))=vmin;
                end
            else
                for j=1:D
                    v(i,j)=w*v(i,j)+c1*rand*(pbest(i,j)-xi(i,j));
                    v(i,find(v(i,j)>vmax))=vmax;
                    v(i,find(v(i,j)<vmin))=vmin;
                end
            end
            Aonum = size(Ao, 1);
            if Aonum<M&&objEi(i)<fitpbest(i)
                Ao=[Ao;Ei(i,:)];
                Aofit=[Aofit objEi(i)];
            elseif Aonum>=M && objEi(i) < fitpbest(i)
                Aonum2 = size(Ao, 1);
                j1 = randi(Aonum2);
                j2 = randi(Aonum2);
                % 确保 j1 和 j2 不相同
                while j1 == j2
                    j2 = randi(Aonum2);
                end
                if Aofit(j1) >= Aofit(j2)
                    Ao(j1, :) = Ei(i, :);
                    Aofit(j1) = objEi(i);
                else                 
                    Ao(j2, :) = Ei(i, :);
                    Aofit(j2) = objEi(i);
                end
            end
        end
        xxi=[];
        for i=1:M
            xi(i,:)=xi(i,:)+v(i,:);
            xi(i,find(xi(i,:)>ximax))=ximax;
            xi(i,find(xi(i,:)<ximin))=ximin;
            obj(i)=costfunction(xi(i,:));
            if obj(i) < fitpbest(i)
                pbest(i,:) = xi(i,:);   
                fitpbest(i) = obj(i);    
            end
        end
        [sortedFitPB, sortOrder] = sort(fitpbest, 'descend');
        sortedPB = pbest(sortOrder, :);
        numGroups = floor(size(Ao, 1) / 2); 
        for i = 1:numGroups
            groupIndex1 = 2 * i - 1;
            groupIndex2 = 2 * i;

            if groupIndex2 <= size(Ao, 1)
                if Aofit(groupIndex1) < Aofit(groupIndex2)
                    e = Ao(groupIndex1, :);
                    ei = groupIndex1;
                else
                    e = Ao(groupIndex2, :);
                    ei = groupIndex2;
                end

                ji = sortOrder(i);

                if Aofit(ei) < fitpbest(ji)
                    pbest(ji, :) = e;
                    fitpbest(ji) = Aofit(ei);
                end               
            end
        end
        for j = 1:M
            if fitpbest(j) < fitgbest
                gbest = pbest(j,:);   
                fitgbest = fitpbest(j);   
            end
        end
%              if abs(fitgbest-lastfitgbest)<10^-2
%                   break;
%              end
% lastfitgbest=fitgbest;
Iterpso=Iterpso+1;

xbest=[xbest fitgbest];
    end
%     fprintf('%d       %f\n',t,fitgbest);
TIME1 = (cputime-H);
 E=[E E2];
u=gbest;
ux=[ux
       u];
BEST=[BEST fitgbest];
[U, fmin, flag_inf,output,lamda] = seqnlpu(u);
lamda.ineqnonlin;
multi_FBR=lamda.ineqnonlin(1,1);
E2=E2-0.0362/(sqrt(1+multi_FBR^2));
 FMIN=[FMIN fmin];
 MM = [MM multi_FBR];
 end
HIO=[];
for num=1:numel(E)
HIO(1,num)=FMIN(num);
HIO(2,num)=-E(num);
end
Time2 = (cputime-H);
nadirPointp = [-12.5,-0.5];
hvtotal=calculatetotalhv(HIO,nadirPointp);
K=numel(FMIN);
sp=SP(HIO,K);







